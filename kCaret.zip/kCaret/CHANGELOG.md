# Changelog

## 1.0.0 (2026-10-05)

First public release.

- A4 pages with per-page margins and page numbers, in Arabic and English.
- Text formatting, lists, quotes, links, emoji, code with syntax colours.
- Tables and images (resize, rotate, float, captions).
- Handwriting, watermark, and page backgrounds (dotted, squares, graph, music).
- Print / PDF and PNG export that match the screen.
- Optional auto-save in the browser.
